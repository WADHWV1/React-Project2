import { useState, useEffect } from "react";

function FormRepairDetail() {
    const [purchaseDate, setPurchaseDate] = useState("");
    const [repairDate, setRepairDate] = useState("");
    const [isWarrantyValid, setIsWarrantyValid] = useState(false);

    // Check warranty validity (purchase date within last 24 months)
    useEffect(() => {
        if (purchaseDate) {
            const purchase = new Date(purchaseDate);
            const today = new Date();
            const diffMonths = (today.getFullYear() - purchase.getFullYear()) * 12 + (today.getMonth() - purchase.getMonth());
            setIsWarrantyValid(diffMonths <= 24);

            // Reset repair date if repairDate is before purchaseDate or before today
            if (repairDate) {
                const repair = new Date(repairDate);
                if (repair <= purchase || repair <= today) {
                    setRepairDate("");
                }
            }
        } else {
            setIsWarrantyValid(false);
            setRepairDate("");
        }
    }, [purchaseDate]);

    const todayISO = new Date().toISOString().split("T")[0];

    // Minimum repair date must be after purchase date and after today
    const getRepairDateMin = () => {
        if (!purchaseDate) return todayISO;
        const purchase = new Date(purchaseDate);
        const today = new Date();

        // Repair date must be later than purchaseDate AND today
        const minDate = purchase > today ? purchase : today;
        return minDate.toISOString().split("T")[0];
    };

    return (
        <>
            <h2>Repair Details</h2>

            {/* Purchase Date */}
            <div className="row mt-1">
                <label htmlFor="purchaseDate" className="col-12 col-md-12 col-lg-4">
                    Purchase Date *
                </label>
                <input
                    id="purchaseDate"
                    className="col-12 col-md-12 col-lg-7"
                    type="date"
                    max={todayISO}
                    required
                    value={purchaseDate}
                    onChange={(e) => setPurchaseDate(e.target.value)}
                />
            </div>

            {/* Repair Date */}
            <div className="row mt-1">
                <label htmlFor="repairDate" className="col-12 col-md-12 col-lg-4">
                    Repair Date *
                </label>
                <input
                    id="repairDate"
                    className="col-12 col-md-12 col-lg-7"
                    type="date"
                    required
                    min={getRepairDateMin()}
                    value={repairDate}
                    onChange={(e) => setRepairDate(e.target.value)}
                />
            </div>

            {/* Warranty checkbox */}
            <div className="row">
                <fieldset className="border border-primary col-12 col-lg-11 ms-1 me-4 mb-3">
                    <legend className="col-11 float-none w-auto">Under Warranty</legend>
                    <div>
                        <label htmlFor="warranty">Warranty</label>
                        <input id="warranty" type="checkbox" disabled={!isWarrantyValid} />
                    </div>
                </fieldset>
            </div>

            {/* IMEI Number */}
            <div className="row mt-1">
                <label htmlFor="imei" className="col-12 col-md-12 col-lg-4">
                    IMEI *
                </label>
                <input
                    id="imei"
                    className="col-12 col-md-12 col-lg-7"
                    type="text"
                    required
                    pattern="^\d{15}$"
                    title="IMEI must be exactly 15 digits"
                />
            </div>

            {/* Make */}
            <div className="row mt-2">
                <label htmlFor="make" className="col-12 col-md-12 col-lg-4">
                    Make *
                </label>
                <select id="make" className="col-12 col-md-12 col-lg-7" required defaultValue="">
                    <option value="" disabled>
                        Select
                    </option>
                    <option value="Apple">Apple</option>
                    <option value="LG">LG</option>
                    <option value="Motorola">Motorola</option>
                    <option value="Nokia">Nokia</option>
                    <option value="Samsung">Samsung</option>
                    <option value="Sony">Sony</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            {/* Model Number */}
            <div className="row mt-1">
                <label htmlFor="modelNumber" className="col-12 col-md-12 col-lg-4">
                    Model Number *
                </label>
                <input
                    id="modelNumber"
                    className="col-12 col-md-12 col-lg-7"
                    type="text"
                    required
                    pattern="^\d+$"
                    title="Only numbers allowed"
                />
            </div>

            {/* Fault Category */}
            <div className="row mt-2">
                <label htmlFor="faultCategory" className="col-12 col-md-12 col-lg-4">
                    Fault Category *
                </label>
                <select id="faultCategory" className="col-12 col-md-12 col-lg-7" required defaultValue="">
                    <option value="" disabled>
                        Select
                    </option>
                    <option value="Battery">Battery</option>
                    <option value="Charging">Charging</option>
                    <option value="Screen">Screen</option>
                    <option value="SD-storage">SD-storage</option>
                    <option value="Software">Software</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            {/* Description */}
            <div className="row mt-1">
                <label htmlFor="description" className="col-12 col-md-12 col-lg-4">
                    Description *
                </label>
                <textarea
                    id="description"
                    className="col-12 col-md-12 col-lg-7"
                    required
                    rows="4"
                    placeholder="Enter detailed issue description here..."
                ></textarea>
            </div>
        </>
    );
}

export default FormRepairDetail;
