import { useState } from "react";

function FormCustomerDetail() {
  const [title, setTitle] = useState("Mr");
  const [fname, setFname] = useState("");
  const [lname, setLname] = useState("");
  const [postcode, setPostcode] = useState("");
  const [phone, setPhone] = useState("");

  return (
    <>
      <h2>Customer Details</h2>

      {/* Customer type radio */}
      <div className="row">
        <fieldset className="border border-primary col-12 col-lg-11 ms-2 me-4">
          <legend className="col-11 float-none w-auto">Customer type *</legend>
          <div>
            <label>
              <input type="radio" name="customer-type" value="customer" defaultChecked required />
              Customer
            </label>
          </div>
          <div>
            <label>
              <input type="radio" name="customer-type" value="business" required />
              Business
            </label>
          </div>
        </fieldset>
      </div>

      {/* Title */}
      <div className="row mt-2">
        <label htmlFor="title" className="col-12 col-md-12 col-lg-4">
          Title *
        </label>
        <select
          id="title"
          className="col-12 col-md-12 col-lg-7"
          required
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        >
          <option value="Mr">Mr</option>
          <option value="Mrs">Mrs</option>
          <option value="Ms">Ms</option>
          <option value="Miss">Miss</option>
          <option value="Dr">Dr</option>
        </select>
      </div>

      {/* First Name */}
      <div className="row mt-1">
        <label htmlFor="fname" className="col-12 col-md-12 col-lg-4">
          First Name *
        </label>
        <input
          id="fname"
          className="col-12 col-md-12 col-lg-7"
          type="text"
          required
          pattern="^[A-Za-z\s\-]+$"
          title="Only letters, spaces and hyphens allowed"
          value={fname}
          onChange={(e) => setFname(e.target.value)}
        />
      </div>

      {/* Last Name */}
      <div className="row mt-1">
        <label htmlFor="lname" className="col-12 col-md-12 col-lg-4">
          Last Name *
        </label>
        <input
          id="lname"
          className="col-12 col-md-12 col-lg-7"
          type="text"
          required
          pattern="^[A-Za-z\s\-]+$"
          title="Only letters, spaces and hyphens allowed"
          value={lname}
          onChange={(e) => setLname(e.target.value)}
        />
      </div>

      {/* Street */}
      <div className="row mt-1">
        <label htmlFor="street" className="col-12 col-md-12 col-lg-4">
          Street *
        </label>
        <input id="street" className="col-12 col-md-12 col-lg-7" type="text" required />
      </div>

      {/* Suburb */}
      <div className="row mt-1">
        <label htmlFor="suburb" className="col-12 col-md-12 col-lg-4">
          Suburb
        </label>
        <input id="suburb" className="col-12 col-md-12 col-lg-7" type="text" />
      </div>

      {/* City */}
      <div className="row mt-1">
        <label htmlFor="city" className="col-12 col-md-12 col-lg-4">
          City *
        </label>
        <input id="city" className="col-12 col-md-12 col-lg-7" type="text" required />
      </div>

      {/* Post Code */}
      <div className="row mt-1">
        <label htmlFor="postcode" className="col-12 col-md-12 col-lg-4">
          Post Code *
        </label>
        <input
          id="postcode"
          className="col-12 col-md-12 col-lg-7"
          type="text"
          required
          pattern="^\d{4}$"
          title="Post code must be exactly 4 digits"
          value={postcode}
          onChange={(e) => setPostcode(e.target.value)}
        />
      </div>

      {/* Phone Number */}
      <div className="row mt-1">
        <label htmlFor="phone" className="col-12 col-md-12 col-lg-4">
          Phone Number *
        </label>
        <input
          id="phone"
          className="col-12 col-md-12 col-lg-7"
          type="tel"
          required
          pattern="^[0-9\s\(\)\-\+]+$"
          title="Only numbers, spaces, parentheses, -, + allowed"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
      </div>

      {/* Email */}
      <div className="row mt-1">
        <label htmlFor="email" className="col-12 col-md-12 col-lg-4">
          Email *
        </label>
        <input id="email" className="col-12 col-md-12 col-lg-7" type="email" required />
      </div>
    </>
  );
}

export default FormCustomerDetail;
