import { useState } from "react";

function FormCourtesyPhone({ customerType = "customer" }) {
    // Full courtesyList data
    const courtesyList = [
        { id: 1, type: "phone", name: "iphone 10", bond: 275 },
        { id: 2, type: "phone", name: "iphone 14", bond: 300 },
        { id: 3, type: "phone", name: "iphone 16", bond: 500 },
        { id: 4, type: "phone", name: "samsung galaxy", bond: 200 },
        { id: 5, type: "phone", name: "nokia", bond: 150 },
        { id: 6, type: "phone", name: "xiaomi", bond: 100 },
        { id: 7, type: "charger", name: "iphone charger", bond: 45 },
        { id: 8, type: "charger", name: "samsung charger", bond: 30 },
        { id: 9, type: "charger", name: "nokia charger", bond: 25 },
        { id: 10, type: "charger", name: "xiaomi", bond: 25 },
    ];

    // State: selected phone and charger IDs (or 0 for none)
    const [selectedPhoneId, setSelectedPhoneId] = useState(0);
    const [selectedChargerId, setSelectedChargerId] = useState(0);

    // Find selected items by id
    const selectedPhone = courtesyList.find(
        (item) => item.id === Number(selectedPhoneId)
    );
    const selectedCharger = courtesyList.find(
        (item) => item.id === Number(selectedChargerId)
    );

    // Calculate total bond, zero if business customer
    const totalBond =
        customerType.toLowerCase() === "business"
            ? 0
            : [selectedPhone, selectedCharger]
                .filter(Boolean)
                .reduce((acc, item) => acc + item.bond, 0);

    // Handlers for select change
    const handlePhoneChange = (e) => setSelectedPhoneId(Number(e.target.value));
    const handleChargerChange = (e) => setSelectedChargerId(Number(e.target.value));

    // Remove handlers (reset selection)
    const removePhone = () => setSelectedPhoneId(0);
    const removeCharger = () => setSelectedChargerId(0);

    return (
        <>
            <h2>Courtesy Phone</h2>

            {/* Phone Select */}
            <div className="row mt-2 ms-3">
                <label className="col-12 col-md-12 col-lg-4" htmlFor="phoneSelect">
                    Choose a phone:
                </label>
                <select
                    id="phoneSelect"
                    className="col-12 col-md-12 col-lg-7"
                    value={selectedPhoneId}
                    onChange={handlePhoneChange}
                >
                    <option value={0}>None</option>
                    {courtesyList
                        .filter((item) => item.type === "phone")
                        .map((phone) => (
                            <option key={phone.id} value={phone.id}>
                                {phone.name} (${phone.bond})
                            </option>
                        ))}
                </select>
                {selectedPhoneId !== 0 && (
                    <button
                        type="button"
                        className="btn btn-sm btn-danger ms-2"
                        onClick={removePhone}
                    >
                        Remove Phone
                    </button>
                )}
            </div>

            {/* Charger Select */}
            <div className="row mt-2 ms-3">
                <label className="col-12 col-md-12 col-lg-4" htmlFor="chargerSelect">
                    Choose a charger:
                </label>
                <select
                    id="chargerSelect"
                    className="col-12 col-md-12 col-lg-7"
                    value={selectedChargerId}
                    onChange={handleChargerChange}
                >
                    <option value={0}>None</option>
                    {courtesyList
                        .filter((item) => item.type === "charger")
                        .map((charger) => (
                            <option key={charger.id} value={charger.id}>
                                {charger.name} (${charger.bond})
                            </option>
                        ))}
                </select>
                {selectedChargerId !== 0 && (
                    <button
                        type="button"
                        className="btn btn-sm btn-danger ms-2"
                        onClick={removeCharger}
                    >
                        Remove Charger
                    </button>
                )}
            </div>

            {/* Table of selected items */}
            <div className="row mt-4 ms-3 me-3 bg-white">
                <table className="table table-bordered" id="borrowItems">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Bond Cost</th>
                        </tr>
                    </thead>
                    <tbody>
                        {!selectedPhone && !selectedCharger && (
                            <tr>
                                <td colSpan="2" className="text-center">
                                    No items selected
                                </td>
                            </tr>
                        )}
                        {selectedPhone && (
                            <tr>
                                <td>{selectedPhone.name}</td>
                                <td>
                                    $
                                    {customerType.toLowerCase() === "business"
                                        ? 0
                                        : selectedPhone.bond}
                                </td>
                            </tr>
                        )}
                        {selectedCharger && (
                            <tr>
                                <td>{selectedCharger.name}</td>
                                <td>
                                    $
                                    {customerType.toLowerCase() === "business"
                                        ? 0
                                        : selectedCharger.bond}
                                </td>
                            </tr>
                        )}
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Total Bond</th>
                            <th>${totalBond}</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </>
    );
}

export default FormCourtesyPhone;
