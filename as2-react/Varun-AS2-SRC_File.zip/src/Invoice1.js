//Function Component
function Invoice() {
    //Component UI: HTML Rendering
    return (<>
        <div style={{ minHeight: '60vh' }}>
            <h1>Booking Sheet</h1>
        </div>
    </>);
}
//Export this component to the entire app, can be re-used or hooked into other Components
export default Invoice;